package com.example.SingletonPrinter;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SingletonPrinterApplication {

	public static void main(String[] args) {
		SpringApplication.run(SingletonPrinterApplication.class, args);
	}

}
