package com.example.SingletonPrinter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SingletonPrinterApplicationTests {

	@Test
	void contextLoads() {
	}

}
